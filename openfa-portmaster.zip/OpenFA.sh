#!/bin/bash
# PortMaster launch script - OpenFA (Kinder & Ferrero - Fresh Adventures)

XDG_DATA_HOME=${XDG_DATA_HOME:-$HOME/.local/share}

if [ -d "/opt/system/Tools/PortMaster/" ]; then
  controlfolder="/opt/system/Tools/PortMaster"
elif [ -d "/opt/tools/PortMaster/" ]; then
  controlfolder="/opt/tools/PortMaster"
elif [ -d "$XDG_DATA_HOME/PortMaster/" ]; then
  controlfolder="$XDG_DATA_HOME/PortMaster"
else
  controlfolder="/roms/ports/PortMaster"
fi

source $controlfolder/control.txt
[ -f "${controlfolder}/mod_${CFW_NAME}.txt" ] && source "${controlfolder}/mod_${CFW_NAME}.txt"
get_controls

GAMEDIR=/$directory/ports/openfa
cd "$GAMEDIR"

> "$GAMEDIR/log.txt" && exec > >(tee "$GAMEDIR/log.txt") 2>&1

# Saves / hiscores / options go to $GAMEDIR/conf/OpenFA (engine uses XDG_DATA_HOME)
export XDG_DATA_HOME="$GAMEDIR/conf"
mkdir -p "$XDG_DATA_HOME/OpenFA"

export LD_LIBRARY_PATH="$GAMEDIR/libs.aarch64:$LD_LIBRARY_PATH"
export SDL_GAMECONTROLLERCONFIG="$sdl_controllerconfig"

# The game data must be copied by the user into openfa/GData
if [ ! -d "$GAMEDIR/GData" ] || [ -z "$(ls -A "$GAMEDIR/GData" 2>/dev/null | grep -v '^README')" ]; then
  echo "GData folder is empty: copy the GData folder of the original game into $GAMEDIR/GData"
  sleep 5
  pm_finish
  exit 1
fi

chmod +x "$GAMEDIR/OpenFA.aarch64"

# gptokeyb maps Start->Enter and Select->Esc (see openfa.gptk) and provides Hotkey+Start quit;
# the rest of the pad is read natively through SDL_GameController.
$GPTOKEYB "OpenFA.aarch64" -c "$GAMEDIR/openfa.gptk" &
pm_platform_helper "$GAMEDIR/OpenFA.aarch64" >/dev/null

./OpenFA.aarch64 --gdata "$GAMEDIR/GData" --fullscreen

pm_finish
