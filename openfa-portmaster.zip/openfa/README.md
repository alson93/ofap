# OpenFA - PortMaster

Port of OpenFA (MIT, https://github.com/Mayo1970/OpenFA) - an engine for
*Kinder & Ferrero - Fresh Adventures*. **Game data is NOT included**: you must own the game.

## Install
1. Install the port (zip) through PortMaster / extract it into `ports/`.
2. Copy the `GData` folder of your original game to `ports/openfa/GData`.
3. Launch from the Ports menu.

## Controls
| Button | Action |
|---|---|
| D-pad / Left stick | Move / menu |
| A | Jump / confirm |
| B | Throw |
| Y | Switch character |
| Start (= Enter) | Join local co-op (2nd player); confirm on the high-score screen |
| L1 | Teleport Milchschnitte near Pinguì (co-op, 2nd player pad) |
| Select (= Esc) | Back to menu |
| Hotkey + Start | Quit |

Saves and high scores: `ports/openfa/conf/OpenFA`.
