#!/usr/bin/env bash
# Build OpenFA for PortMaster (aarch64 / glibc).
# Run it inside the PortMaster aarch64 build container, e.g.:
#   docker run --rm -it --platform linux/arm64 -v "$PWD":/work -w /work \
#     ghcr.io/monkeyx-net/portmaster-build-templates/portmaster-builder:aarch64-latest \
#     ./build-portmaster.sh /work/OpenFA-1.0
# (or natively on any aarch64 Linux with gcc + libsdl2-dev).
# CMakeLists.txt references a tests/ folder that is not in the release zip,
# so we compile directly with gcc instead.
set -euo pipefail
SRC=${1:-OpenFA-1.0}
OUT=${2:-openfa/OpenFA.aarch64}
cd "$SRC"
gcc -std=gnu11 -O2 -Iinclude -DFA_HAVE_SDL2=1 \
  src/core/*.c src/game/*.c src/app/*.c \
  src/platform/fa_platform.c src/platform/fa_backend_null.c \
  src/platform/fa_backend_sdl2.c src/platform/fa_time_posix.c \
  src/platform/fa_paths_posix.c tools/fa_slice.c \
  $(sdl2-config --cflags --libs) -lm -o "../$OUT"
echo "built $OUT"
